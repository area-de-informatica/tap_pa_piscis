<template>
  <v-app-bar app color="primary" dark>
    <v-toolbar-title class="text-h6 font-weight-bold">OVA: Búsqueda Sistemática en Bases de Datos</v-toolbar-title>
  </v-app-bar>
</template>

<script setup>
</script>