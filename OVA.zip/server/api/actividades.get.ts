export default defineEventHandler(() => {
  return {
    actividades: [
      "Búsqueda guiada paso a paso en Google Scholar",
      "Juego de emparejamiento: operadores booleanos",
      "Simulación de estrategia de búsqueda en una base real",
      "Caso práctico: formular una pregunta de investigación y buscar fuentes"
    ]
  }
})