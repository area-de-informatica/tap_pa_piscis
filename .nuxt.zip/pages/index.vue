<template>
  <div class="p-8 text-center">
    <div v-if="loading">Cargando...</div>
    <div v-else-if="error">Error: {{ error.message }}</div>
    <div v-else>
      <h1 class="text-3xl font-bold">{{ data.titulo }}</h1>
      <p class="mb-4">{{ data.descripcion }}</p>
      <NuxtLink to="/contenido" class="bg-blue-500 text-white px-4 py-2 rounded">Comenzar</NuxtLink>
      <FooterInfo />
    </div>
  </div>
</template>

<script setup>
import { useInicioStore } from '@/stores/useInicioStore'
import FooterInfo from '@/components/FooterInfo.vue'

const store = useInicioStore()
store.fetchInicio()

const { data, loading, error } = store
</script>