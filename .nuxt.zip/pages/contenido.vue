<template>
  <div class="p-6">
    <h1 class="text-2xl font-bold text-center mb-6">Contenido por Módulo</h1>
    <div v-if="loading">Cargando contenido...</div>
    <div v-else-if="error">Error al cargar: {{ error.message }}</div>
    <div v-else>
      <div v-for="modulo in modulos" :key="modulo.id" class="mb-6 p-4 border rounded-lg shadow">
        <h2 class="text-xl font-semibold text-blue-700">{{ modulo.titulo }}</h2>
        <ul class="list-disc list-inside mt-2">
          <li v-for="tema in modulo.temas" :key="tema">{{ tema }}</li>
        </ul>
      </div>
    </div>
    <FooterInfo />
  </div>
</template>

<script setup>
import { useContenidoStore } from '@/stores/useContenidoStore'
import FooterInfo from '@/components/FooterInfo.vue'

const store = useContenidoStore()
store.fetchContenido()

const { modulos, loading, error } = store
</script>
