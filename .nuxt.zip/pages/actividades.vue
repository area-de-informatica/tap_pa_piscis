<template>
  <div class="p-6">
    <h1 class="text-2xl font-bold text-center mb-6">Actividades del OVA</h1>
    <div v-if="loading">Cargando actividades...</div>
    <div v-else-if="error">Error al cargar: {{ error.message }}</div>
    <div v-else>
      <ul class="list-disc list-inside space-y-2">
        <li v-for="actividad in actividades" :key="actividad">{{ actividad }}</li>
      </ul>
    </div>
    <FooterInfo />
  </div>
</template>

<script setup>
import { useActividadesStore } from '@/stores/useActividadesStore'
import FooterInfo from '@/components/FooterInfo.vue'

const store = useActividadesStore()
store.fetchActividades()

const { actividades, loading, error } = store
</script>
