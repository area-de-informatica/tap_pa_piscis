<template>
  <div class="p-8">
    <h1 class="text-3xl font-bold mb-4">Créditos</h1>
    <p><strong>Docente:</strong> {{ store.docente }}</p>
    <p><strong>Institución:</strong> {{ store.institucion }}</p>
    <p><strong>Curso:</strong> {{ store.curso }}</p>
    <p><strong>Licencia:</strong> {{ store.licencias }}</p>
    <div class="mt-4">
      <strong>Tecnologías utilizadas:</strong>
      <ul class="list-disc ml-5">
        <li v-for="(tech, index) in store.tecnologias" :key="index">{{ tech }}</li>
      </ul>
    </div>
  </div>
</template>

<script setup lang="ts">
const store = useCreditosStore()
onMounted(() => store.fetchCreditos())
</script>