<template>
  <div class="p-6">
    <h1 class="text-2xl font-bold mb-4">Evaluación</h1>
    <div v-if="evaluacionStore.loading">Cargando evaluación...</div>
    <div v-else>
      <section class="mb-6">
        <h2 class="text-xl font-semibold">Cuestionario</h2>
        <p><strong>Tipo:</strong> {{ evaluacionStore.cuestionario.tipo }}</p>
        <p><strong>Número de preguntas:</strong> {{ evaluacionStore.cuestionario.preguntas }}</p>
        <p><strong>Formatos:</strong> {{ evaluacionStore.cuestionario.formatos.join(', ') }}</p>
      </section>

      <section class="mb-6">
        <h2 class="text-xl font-semibold">Entregable</h2>
        <p>{{ evaluacionStore.entregable }}</p>
      </section>

      <section>
        <h2 class="text-xl font-semibold">Rúbrica</h2>
        <ul class="list-disc list-inside">
          <li v-for="nivel in evaluacionStore.rubrica" :key="nivel.nivel">
            <strong>{{ nivel.nivel }}:</strong> {{ nivel.descripcion }}
          </li>
        </ul>
      </section>
    </div>
  </div>
</template>

<script setup>
import { useEvaluacionStore } from '@/stores/useEvaluacionStore'
const evaluacionStore = useEvaluacionStore()
evaluacionStore.fetchEvaluacion()
</script>
