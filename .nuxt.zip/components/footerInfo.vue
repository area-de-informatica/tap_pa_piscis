<template>
  <footer class="mt-8 text-sm text-center text-gray-600 border-t pt-4">
    <p>EMID: {{ emid }}</p>
    <p>PROD: {{ prod }}</p>
    <p>MODEL: {{ model }}</p>
  </footer>
</template>

<script setup>
import { useInicioStore } from '@/stores/useInicioStore'
const { data } = useInicioStore()
const emid = computed(() => data?.emid || '')
const prod = computed(() => data?.prod || '')
const model = computed(() => data?.model || '')
</script>