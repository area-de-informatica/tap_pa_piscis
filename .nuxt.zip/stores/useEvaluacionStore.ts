mport { defineStore } from 'pinia'

export const useEvaluacionStore = defineStore('evaluacion', {
  state: () => ({
    cuestionario: {},
    entregable: '',
    rubrica: [],
    loading: true,
    error: null
  }),
  actions: {
    async fetchEvaluacion() {
      try {
        this.loading = true
        const res = await $fetch('/api/evaluacion')
        this.cuestionario = res.cuestionario
        this.entregable = res.entregable
        this.rubrica = res.rubrica
      } catch (err) {
        this.error = err
      } finally {
        this.loading = false
      }
    }
  }
})
