 state: () => ({
    actividades: [],
    loading: true,
    error: null
  }),
  actions: {
    async fetchActividades() {
      try {
        this.loading = true
        const res = await $fetch('/api/actividades')
        this.actividades = res.actividades
      } catch (err) {
        this.error = err
      } finally {
        this.loading = false
      }
    }
  }
})