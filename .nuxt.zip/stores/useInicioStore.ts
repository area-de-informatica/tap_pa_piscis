import { defineStore } from 'pinia'

export const useInicioStore = defineStore('inicio', {
  state: () => ({
    data: null,
    loading: true,
    error: null
  }),
  actions: {
    async fetchInicio() {
      try {
        this.loading = true
        const res = await $fetch('/api/inicio')
        this.data = res
      } catch (err) {
        this.error = err
      } finally {
        this.loading = false
      }
    }
  }
})
