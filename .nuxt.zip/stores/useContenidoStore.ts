import { defineStore } from 'pinia'

export const useContenidoStore = defineStore('contenido', {
  state: () => ({
    modulos: [],
    loading: true,
    error: null
  }),
  actions: {
    async fetchContenido() {
      try {
        this.loading = true
        const res = await $fetch('/api/contenido')
        this.modulos = res.modulos
      } catch (err) {
        this.error = err
      } finally {
        this.loading = false
      }
    }
  }
})