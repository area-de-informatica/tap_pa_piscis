"use client"

import  from "../plugins/vuetify"

export default function SyntheticV0PageForDeployment() {
  return < />
}